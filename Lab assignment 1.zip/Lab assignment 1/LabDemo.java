public class LabDemo {

    public static void main(String[] args) {

        Date d1 = new Date(10, 5, 2026);
        Date d2 = new Date(12, 5, 2026);

        Lab lab1 = new Lab();

        Lab lab2 = new Lab("FAST University", "Computer Science", "BCS-C",
                "Programming Lab", 40, 10, d1);

        Lab lab3 = new Lab("Networking Lab", 25);

        Lab lab4 = new Lab(lab2);

        lab2.bookComputers(5);
        lab2.cancelBooking(3);

        if (lab2.equals(lab4))
            System.out.println("Lab2 and Lab4 are equal");
        else
            System.out.println("Lab2 and Lab4 are not equal");

        System.out.println(lab1);
        System.out.println(lab2);
        System.out.println(lab3);
        System.out.println(lab4);

        System.out.println("Total Lab Objects Created: " + Lab.getTotalLabs());
    }
}