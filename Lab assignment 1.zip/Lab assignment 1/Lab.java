public class Lab {

    private static int counter = 0;
    private static final String ID_PREFIX = "LAB";

    private String id;
    private String universityName;
    private String departmentName;
    private String sectionName;
    private String labName;
    private int totalComputers;
    private int bookedComputers;
    private Date labDate;

    private String generateID() {
        counter++;
        return ID_PREFIX + counter;
    }

    public Lab() {
        this("COMSATS University", "Computer Science", "BCS-C", "Programming Lab", 30, 0, new Date(1,1,2026));
    }

    public Lab(String labName, int totalComputers) {
        this("COMSATS University", "Computer Science", "BCS-D", labName, totalComputers, 0, new Date(5,5,2026));
    }

    public Lab(String departmentName, String sectionName) {
        this("COMSATS University", departmentName, sectionName, "Networking Lab", 35, 0, new Date(10,5,2026));
    }

    public Lab(String universityName, String departmentName, String sectionName,
               String labName, int totalComputers, int bookedComputers, Date labDate) {

        this.id = generateID();
        this.universityName = universityName;
        this.departmentName = departmentName;
        this.sectionName = sectionName;
        this.labName = labName;
        this.totalComputers = totalComputers;
        this.bookedComputers = bookedComputers;
        this.labDate = new Date(labDate);
    }

    public Lab(Lab l) {

        this.id = generateID();
        this.universityName = l.universityName;
        this.departmentName = l.departmentName;
        this.sectionName = l.sectionName;
        this.labName = l.labName;
        this.totalComputers = l.totalComputers;
        this.bookedComputers = l.bookedComputers;
        this.labDate = new Date(l.labDate);
    }

    public static int getTotalLabs() {
        return counter;
    }

    public void bookComputers(int count) {

        if (bookedComputers + count <= totalComputers)
            bookedComputers += count;
    }

    public void cancelBooking(int count) {

        if (bookedComputers - count >= 0)
            bookedComputers -= count;
    }

    public int availableComputers() {
        return totalComputers - bookedComputers;
    }

    public boolean equals(Object obj) {

        if (this == obj)
            return true;

        if (obj == null || getClass() != obj.getClass())
            return false;

        Lab l = (Lab) obj;

        return labName.equals(l.labName) &&
               departmentName.equals(l.departmentName) &&
               labDate.equals(l.labDate);
    }

    public String toString() {

        return "\n---------------------------------\n"
                + "Lab ID: " + id + "\n"
                + "University: " + universityName + "\n"
                + "Department: " + departmentName + "\n"
                + "Section: " + sectionName + "\n"
                + "Lab Name: " + labName + "\n"
                + "Total Computers: " + totalComputers + "\n"
                + "Booked Computers: " + bookedComputers + "\n"
                + "Available Computers: " + availableComputers() + "\n"
                + "Lab Date: " + labDate + "\n"
                + "---------------------------------\n";
    }
}