// Date.java

public class Date {

    private int day;
    private int month;
    private int year;

    // Parameterized Constructor
    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    // Copy Constructor
    public Date(Date d) {
        this.day = d.day;
        this.month = d.month;
        this.year = d.year;
    }

    // Getters
    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    // Setters
    public void setDay(int day) {
        if(day >= 1 && day <= 31)
            this.day = day;
    }

    public void setMonth(int month) {
        if(month >= 1 && month <= 12)
            this.month = month;
    }

    public void setYear(int year) {
        if(year > 0)
            this.year = year;
    }

    // toString
    public String toString() {
        return day + "/" + month + "/" + year;
    }

    // equals
    public boolean equals(Object obj) {

        if(this == obj)
            return true;

        if(obj == null || getClass() != obj.getClass())
            return false;

        Date d = (Date) obj;

        return day == d.day && month == d.month && year == d.year;
    }
}